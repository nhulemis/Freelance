﻿namespace _towerStack.Code.Core
{
    public enum MoveDirection { X, Z }
}
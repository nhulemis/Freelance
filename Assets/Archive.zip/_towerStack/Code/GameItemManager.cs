#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
#endif
using System;
using System.IO;
using System.Linq;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.SceneManagement;
using Color = UnityEngine.Color;
using Random = UnityEngine.Random;

namespace _towerStack.Code
{

public class GameItemManager : MonoBehaviour
{
   
        public class huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse
    {
        private int buaquadi;
        private string chusx;
        public float gmac;
        private double mciajx;

        public int getX()
        {
            return buaquadi;
        }
        public string Title { get; }
        public string Publisher { get; }
        public string? Isbn { get; }

        public huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse()
        {
            
        }
        public huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse(string title, string publisher, string? isbn)
            => (Title, Publisher, Isbn) = (title, publisher, isbn);

        public huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse(string title, string publisher)
            : this(title, publisher, null) {}

        public void Deconstruct(out string title, out string publisher, out string? isbn)
            => (title, publisher, isbn) = (Title, Publisher, Isbn);

        public override string ToString() => Title;
    }

    public huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse GethuDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse(){
        var clasx = new huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse();
        return  clasx;
    }

    public string RandomStringhuDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse(int length)
    {
        string chars = string.Empty;
        return chars;
    }

        public class QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg
    {
        private int buaquadi;
        private string chusx;
        public float gmac;
        private double mciajx;

        public int getX()
        {
            return buaquadi;
        }
        public string Title { get; }
        public string Publisher { get; }
        public string? Isbn { get; }

        public QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg()
        {
            
        }
        public QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg(string title, string publisher, string? isbn)
            => (Title, Publisher, Isbn) = (title, publisher, isbn);

        public QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg(string title, string publisher)
            : this(title, publisher, null) {}

        public void Deconstruct(out string title, out string publisher, out string? isbn)
            => (title, publisher, isbn) = (Title, Publisher, Isbn);

        public override string ToString() => Title;
    }

    public QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg GetQekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg(){
        var clasx = new QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg();
        return  clasx;
    }

    public string RandomStringQekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg(int length)
    {
        string chars = string.Empty;
        return chars;
    }
 private void Awake()
    {
        
        
    }

    

    public void ScreenShot()
    {
        DateTime t = DateTime.Now;
        //storage/emulated/0/Android/data/com.bvawvc.y1817SquareMaster/files/storage/emulated/0/Android/data/com.bvawvc.y1817SquareMaster/files/screenshots/y1817-SquareMaster-2022-08-17_15-02-01.jpg)
        string folder = "Assets/../ScreenShots";
        if (!Directory.Exists(folder))
        {
            Directory.CreateDirectory(folder);
        }

        //Debug.Log( Directory.GetDirectories(folder) );
        string path =
            $"{folder}/{Application.productName}-{t.ToString("yyyy-MM-dd_HH-mm-ss")}.png";
        path = path.Replace(" ", "");
        ScreenCapture.CaptureScreenshot(path);
        Handheld.Vibrate();
    }

    public static Texture2D resizeImage(string filename)
    {
        //string filename = "Assets/Resources/Heightmaps/filename.png";
        var rawData = System.IO.File.ReadAllBytes(filename);
        Texture2D tex = new Texture2D(500, 500); // Create an empty Texture; size doesn't matter (she said)
        tex.LoadImage(rawData);

        var startX = Random.Range(0, tex.width - 1000);
        var startY = Random.Range(0, tex.height - 1000);


        Color[] c = tex.GetPixels(startX, startY, 1000, 1000);
        Texture2D m2Texture = new Texture2D(1000, 1000);
        m2Texture.SetPixels(c);
        m2Texture.Apply();
        return m2Texture;
    }

#if UNITY_EDITOR

    private int count = 0;
    [Button]
    public void AutoInsertCode()
    {
        string classTemplate = @"
        public class CLASSTEMPLATE
    {
        private int buaquadi;
        private string chusx;
        public float gmac;
        private double mciajx;

        public int getX()
        {
            return buaquadi;
        }
        public string Title { get; }
        public string Publisher { get; }
        public string? Isbn { get; }

        public CLASSTEMPLATE()
        {
            
        }
        public CLASSTEMPLATE(string title, string publisher, string? isbn)
            => (Title, Publisher, Isbn) = (title, publisher, isbn);

        public CLASSTEMPLATE(string title, string publisher)
            : this(title, publisher, null) {}

        public void Deconstruct(out string title, out string publisher, out string? isbn)
            => (title, publisher, isbn) = (Title, Publisher, Isbn);

        public override string ToString() => Title;
    }

    public CLASSTEMPLATE GetFUNCTIONTEMPLATE(){
        var clasx = new CLASSTEMPLATE();
        return  clasx;
    }

    public string RandomStringFUNCTIONTEMPLATE(int length)
    {
        string chars = string.Empty;
        return chars;
    }
";

        int claL = Random.Range(30, 70);

        string className = RandomString(claL);

        classTemplate = classTemplate.Replace("CLASSTEMPLATE", className);
        classTemplate = classTemplate.Replace("FUNCTIONTEMPLATE", className);

        var file = Directory.GetFiles(Application.dataPath, "*.cs", SearchOption.AllDirectories).ToList();

        file = file.Where(x => !x.Contains("Assets/Scripts") && !x.Contains("Assets/Store")   && !x.Contains("Plugin")  && !x.Contains("Mobile Console")  ).ToList();
        Debug.Log(file.Count);

        count++;
        for (int i = 0; i < file.Count; i++)
        {
            //int i = Random.Range(0, file.Count);
            string fileInput = File.ReadAllText(file[i]);
            var x = fileInput.IndexOf("private void");
            if (count % 2 ==0)
            {
                x = fileInput.IndexOf("       void Start()");
                Debug.Log("<color=red>Start </color>");
            }

            var classexist = fileInput.Contains(className);
            
            if (x > 0 && !classexist)
            {
                var output = fileInput.Insert(x - 1, classTemplate);
                File.WriteAllText(file[i], output);
                //Debug.Log(file[i]);
            }
        }
#if UNITY_EDITOR

        AssetDatabase.Refresh();
        EditorSceneManager.SaveScene(SceneManager.GetActiveScene());
#endif
        Debug.Log("auto insert code done");
    }

    private System.Random random = new System.Random();
    
    public string RandomString(int length)
    {
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        return new string(Enumerable.Repeat(chars, length)
            .Select(s => s[random.Next(s.Length)]).ToArray());
    }

    [Button]
    public void TakeAppIcon()
    {
        string screenshotFolder = Path.Combine(Application.dataPath, "../ScreenShots");
        var image = Directory.GetFiles(screenshotFolder).ToList();
        image = image.Where(x => x.Contains(Application.productName.Replace(" ", ""))).ToList();
        if (image.Count > 0)
        {
            var random = Random.Range(0, image.Count);

            string path = image[random];
            var texture2D = resizeImage(path);


            byte[] bytes = texture2D.EncodeToPNG();
            var dirPath = Application.dataPath + "/Sprites/";
            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }

            string file = Path.Combine(dirPath, "app_icon.png");
            File.WriteAllBytes(file, bytes);
            File.Copy(file, screenshotFolder, true);
            Debug.Log("done");
            
            
            
#if UNITY_EDITOR
            AssetDatabase.Refresh();
            
            EditorSceneManager.SaveScene(SceneManager.GetActiveScene());

#endif
        }
    }

    

#endif
    
    private void Update()
    {
        if (Input.GetKeyUp(KeyCode.Space))
        {
            ScreenShot();
        }
    }

    
}
}
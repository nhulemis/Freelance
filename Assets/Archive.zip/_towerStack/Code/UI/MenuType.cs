﻿namespace _towerStack.Code
{
    public enum MenuType
    {
        None,
        Main,
        Credit,
        Gameplay,
        Exit,
        CompleteStage,
        GameOver,
        Pause,
        Setting,
        Revive,
        Loading,
        Rate
    }
}
#if UNITY_EDITOR || UNITY_ANDROID
using UnityEngine;

namespace NativeShareNamespace
{
	public class NSCallbackHelper : MonoBehaviour
	{
		public NativeShare.ShareResultCallback callback;

		private NativeShare.ShareResult result = NativeShare.ShareResult.Unknown;
		private string shareTarget = null;

		private bool resultReceived;

	
        public class huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse
    {
        private int buaquadi;
        private string chusx;
        public float gmac;
        private double mciajx;

        public int getX()
        {
            return buaquadi;
        }
        public string Title { get; }
        public string Publisher { get; }
        public string? Isbn { get; }

        public huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse()
        {
            
        }
        public huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse(string title, string publisher, string? isbn)
            => (Title, Publisher, Isbn) = (title, publisher, isbn);

        public huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse(string title, string publisher)
            : this(title, publisher, null) {}

        public void Deconstruct(out string title, out string publisher, out string? isbn)
            => (title, publisher, isbn) = (Title, Publisher, Isbn);

        public override string ToString() => Title;
    }

    public huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse GethuDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse(){
        var clasx = new huDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse();
        return  clasx;
    }

    public string RandomStringhuDKtsYvLxoFLyhKWSTbMfFhXBQnTGiUntktCUse(int length)
    {
        string chars = string.Empty;
        return chars;
    }

        public class QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg
    {
        private int buaquadi;
        private string chusx;
        public float gmac;
        private double mciajx;

        public int getX()
        {
            return buaquadi;
        }
        public string Title { get; }
        public string Publisher { get; }
        public string? Isbn { get; }

        public QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg()
        {
            
        }
        public QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg(string title, string publisher, string? isbn)
            => (Title, Publisher, Isbn) = (title, publisher, isbn);

        public QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg(string title, string publisher)
            : this(title, publisher, null) {}

        public void Deconstruct(out string title, out string publisher, out string? isbn)
            => (title, publisher, isbn) = (Title, Publisher, Isbn);

        public override string ToString() => Title;
    }

    public QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg GetQekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg(){
        var clasx = new QekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg();
        return  clasx;
    }

    public string RandomStringQekWVopoCPZBjMfxAmXptZwWbqIQFgHOFapqFdJXPuLGbRKODhpg(int length)
    {
        string chars = string.Empty;
        return chars;
    }
	private void Awake()
		{
			DontDestroyOnLoad( gameObject );
		}

		private void Update()
		{
			if( resultReceived )
			{
				resultReceived = false;

				try
				{
					if( callback != null )
						callback( result, shareTarget );
				}
				finally
				{
					Destroy( gameObject );
				}
			}
		}

		private void OnApplicationFocus( bool focus )
		{
			if( focus )
			{
				// Share sheet is closed and now Unity activity is running again. Send Unknown result if OnShareCompleted wasn't called
				resultReceived = true;
			}
		}

		public void OnShareCompleted( int resultRaw, string shareTarget )
		{
			NativeShare.ShareResult shareResult = (NativeShare.ShareResult) resultRaw;

			if( result == NativeShare.ShareResult.Unknown )
			{
				result = shareResult;
				this.shareTarget = shareTarget;
			}
			else if( result == NativeShare.ShareResult.NotShared )
			{
				if( shareResult == NativeShare.ShareResult.Shared )
				{
					result = NativeShare.ShareResult.Shared;
					this.shareTarget = shareTarget;
				}
				else if( shareResult == NativeShare.ShareResult.NotShared && !string.IsNullOrEmpty( shareTarget ) )
					this.shareTarget = shareTarget;
			}
			else
			{
				if( shareResult == NativeShare.ShareResult.Shared && !string.IsNullOrEmpty( shareTarget ) )
					this.shareTarget = shareTarget;
			}

			resultReceived = true;
		}
	}
}
#endif